<!-- Header -->
<header id="header" class="alt">
	<h1><a href="index.php">Datos del Tiempo</a></h1>
<nav id="nav">
			<ul>
				<li class="special">
			<a href="#menu" class="menuToggle"><span>Menu</span></a>
		<div id="menu">
			<ul>
				<li><a href="index.php">Principal</a></li>
				<li><a href="configurar.php">Configurar</a></li>
				<li><a href="guia.php">Guia de uso</a></li>
				<li><a href="actualizar.php">Actualizar</a></li>
			</ul>
		</div>
				</li>
			</ul>
		</nav>
</header>