<?php error_reporting(0);
ini_set('error_reporting', E_ALL);error_reporting(0);
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Datos del tiempo 2.6.5</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
<script type="text/javascript" src="includes/javascript.js"></script>
	</head>
	<body>
<div id="page-wrapper">
<?php include('includes/menu.php');?>
<article id="main">
						
							<center>
                            <h2>Configuracion</h2>
                           
                            </center>
						
						<section class="wrapper style5">
<p>
<div class="row">

<div class="form-group col-sm-6">
<div class="help-block with-errors"></div>
<p><strong>Copiar y Pegar</strong> esta direccion:<br>
<code><font color="#FF3300" size="+1"><?php $zararadio=str_replace("/","\\",$_SERVER['DOCUMENT_ROOT']."/Currenweather/currenweather.html");echo $zararadio;?></font></code> <a href="javascript:void(1);" onClick="seleccionarCode(this,1);">Seleccionar</a><br>
En Zararadio->Herramientas->Opciones->HTH<br>
Importar desde un archivo->Marcar casilla->Pegar direccion -&gt;Luego-&gt; Aceptar.</p></div><!-- end form-group -->


</div>
</div><!--End row -->
<!-- Popup end -->
</div><!-- end item-wrap -->
</div><!--End col -->
</div><!--End tab-content -->
</div><!--End row -->
</div><!--End container -->
	
        </p>
        <center><p>Para obtener el ID de Usuario debes ingresar a nuestra <a href="https://meteo.riotercero.tk/login.php" target="_blank">página web</a></p></center>
<?php echo $div_actualizar;?>
</div>
</section>
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>
	</body>
</html>